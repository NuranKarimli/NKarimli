package payroll;

enum Status {

    IN_PROGRESS, //
    COMPLETED, //
    CANCELLED
}